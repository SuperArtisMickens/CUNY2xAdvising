#include <iostream>


/*
    // HOMEWORK 4
    // HEADER FILE
    // K. Artis-Mickens
*/

// Put all your class declarations here

class Rectangle{
    public:
        Rectangle(double h, double b){
            height = h;
            base = b;
        }
        double getArea();

    private:
        double height;
        double base;
};

double Rectangle::getArea(){
    return(height * base);
}


class Trapezoid{
    public:
        Trapezoid(double th, double h, double b){
            topheight = th;
            height = h;
            base = b;
        }
        double getArea();

    private:
        double topheight;
        double height;
        double base;
};

double Trapezoid::getArea(){
    return(((topheight + height)/2) * base);
}
