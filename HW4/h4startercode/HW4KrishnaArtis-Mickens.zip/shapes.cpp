#include <iostream>

using namespace std;
/*
    // HOMEWORK 4
    // IMPLEMENTATION FILE
    // YOUR NAME HERE
*/

// Put all your class member function definitions here

class Shape{
    public:
        Rectangle(double h, double b){
            height = h;
            base = b;
        }
        double getArea();

    private:
        double height;
        double base;
};

double Rectangle::getArea(){
    return(height * base);
}



class Rectangle{
    public:
        setHeight(int s_h){
            height = s_h;
        }

        setBase(int s_b){
            base = s_b;
        }
        
        Rectangle(double h, double b){
            height = h;
            base = b;
        }
        double getArea();

    private:
        double height;
        double base;
};

double Rectangle::getArea(){
    return(height * base);
}


class Trapezoid{
    public:
        setTopBase(int s_tb){
            topbase = s_tb;
        }

        setBase(int s_b){
            base = s_b;
        }
        
        setHeight(int s_h){
            height = s_h;
        }

        
        
        Trapezoid(double tb, double h, double b){
            topbase = tb;
            height = h;
            base = b;
        }
        double getArea();

    private:
        double topbase;
        double height;
        double base;
};

double Trapezoid::getArea(){
    return(((topbase + height)/2) * base);
}

